﻿Imports System.IO
Public Class Form3
    Dim chemin As String
    Dim nb_ligne As Integer
    Dim Emplacement As String = "C:\Users\ali abdelhak\Desktop\1ére lig\preven\projet\projet\projet\informations_enfant.txt"
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'choisir une image 
        choisirimage.ShowDialog()
        If (choisirimage.ShowDialog = 1) Then
            Dim File1 As String = choisirimage.FileName
            Dim test As String = File1.Substring(File1.IndexOf(".") + 1, Len(File1) - Len(File1.Substring(0, File1.IndexOf(".") + 1)))
            If (test <> "jpg" And test <> "JPG" And test <> "JPEG" And test <> "jpeg" And test <> "BMP" And test <> "bmp" And test <> "PNG" And test <> "png") Then
                MsgBox("erreur , svp entrez une image de format JPEG , JPG , BMP ou PNG", MsgBoxStyle.Critical, "erreur")
            Else
                Dim File As String = choisirimage.FileName
                chemin = File
                PictureBox1.Image = Image.FromFile(File)
            End If
        End If
    End Sub
    Sub effacer(ByVal Emplacement)
        Dim fs As FileStream
        Dim sr As StreamReader
        fs = New FileStream(Emplacement, FileMode.Open, FileAccess.Read)
        sr = New StreamReader(fs)
        Dim Ligne As String
        Dim ligne_f As String
        Dim i As Integer
        Dim nb As Integer
        While (sr.Peek <> -1)
            If (i = 0) Then
                nb = nb + 1
            End If
            i = i + 1
            Ligne = sr.ReadLine()
            If (nb <> nb_ligne) Then
                ligne_f = ligne_f & Ligne & vbCrLf
            End If
            If (i = 17) Then
                i = 0
            End If
        End While
        fs.Close()
        sr.Close()
        fs = New FileStream(Emplacement, FileMode.Create, FileAccess.Write)
        Dim sw As StreamWriter
        sw = New StreamWriter(fs)
        sw.Write(ligne_f)
        sw.Close()
        fs.Close()
    End Sub
    Function exist(ByVal Emplacement As String, ByVal Nom As String, ByVal prenom As String, ByVal dat As String, ByVal npére As String, ByVal ncinp As String, ByVal nmére As String, ByVal ncinm As String) As Boolean

        Dim testi As Integer = 0
        Dim fs As FileStream
        Dim sr As StreamReader
        fs = New FileStream(Emplacement, FileMode.Open, FileAccess.Read)
        sr = New StreamReader(fs)
        'nombre des lignes de fichier
        Dim info_fich(17) As String
        Dim cat_abonn(9) As String
        Dim club(20) As String
        Dim i = 0
        Dim ligne As String
        Dim k As Integer
        nb_ligne = 0
        While (sr.Peek <> -1 And i <> 17)
            If (i = 0) Then
                nb_ligne = nb_ligne + 1
            End If
            ligne = sr.ReadLine()
            info_fich(i) = ligne
            i += 1
            If (i = 5) Then
                cat_abonn = Split(ligne, " ")
            End If
            If (i = 9) Then
                club = Split(ligne, " ")
                k = 0
                For c As Integer = 0 To Len(ligne) - 1
                    If (ligne(c) = " ") Then
                        k = k + 1
                    End If
                Next
            End If
            If (ligne = Nom And i = 2) Then
                testi = testi + 1
            End If
            If (ligne = prenom And i = 3) Then
                testi = testi + 1
            End If
            If (ligne = dat And i = 4) Then
                testi = testi + 1
            End If
            If (ligne = npére And i = 11) Then
                testi = testi + 1
            End If
            If (ligne = ncinp And i = 12) Then
                testi = testi + 1
            End If
            If (ligne = nmére And i = 13) Then
                testi = testi + 1
            End If
            If (ligne = ncinm And i = 14) Then
                testi = testi + 1
            End If
            If (i = 6) Then
                chemin = ligne
            End If
            If (i = 17) Then
                i = 0
                testi = 0
            End If
            If (testi = 7 And i = 16) Then
                i = 17
            End If
        End While
        If (testi = 7) Then

            If (cat_abonn(1) = "journée_complet") Then
                CheckBox1.Checked = True
            End If
            If (cat_abonn(1) = "demi_journée") Then
                CheckBox2.Checked = True
            End If
            If (cat_abonn(3) = "avec_repas") Then
                CheckBox3.Checked = True
            End If
            If (cat_abonn(3) = "sans_repas") Then
                CheckBox4.Checked = True
            End If
            If (File.Exists(Emplacement)) Then
                PictureBox1.Image = Image.FromFile(info_fich(5))
            Else
                MsgBox("l'emplacement de l'image de l'enfant n'est plus dans son ancien emplacement", MsgBoxStyle.Information, "information")
            End If
            TextBox3.Text = info_fich(6)
            TextBox4.Text = info_fich(7)
            Dim c As Integer
            For c = 0 To k
                If (club(c) = "dance") Then
                    CheckBox5.Checked = True
                End If
                If (club(c) = "quran") Then
                    CheckBox6.Checked = True
                End If
                If (club(c) = "sport") Then
                    CheckBox7.Checked = True
                End If
                If (club(c) = "musique") Then
                    CheckBox8.Checked = True
                End If
                If (club(c) = "calcul_mentale") Then
                    CheckBox9.Checked = True
                End If
                If (club(c) = "developpement_personnel") Then
                    CheckBox10.Checked = True
                End If
            Next
            TextBox9.Text = info_fich(14)
            TextBox10.Text = info_fich(15)
        End If
        sr.Close()
        fs.Close()
        Return testi = 7
    End Function
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim Nom As String = TextBox1.Text
        Dim prenom As String = TextBox2.Text
        Dim selected_date As DateTime = DateTimePicker1.Value
        Dim dat As String = selected_date.ToString().Substring(0, 10)
        Dim Nometpren_pére As String = TextBox5.Text
        Dim Ncin_pére As String = TextBox6.Text
        Dim Nometpren_mére As String = TextBox7.Text
        Dim Ncin_mére As String = TextBox8.Text
        If (exist(Emplacement, Nom, prenom, dat, Nometpren_pére, Ncin_pére, Nometpren_mére, Ncin_mére) = True) Then
            Label2.Visible = True
            Label6.Visible = True
            Label7.Visible = True
            Label8.Visible = True
            Label10.Visible = True
            Label9.Visible = True
            Label11.Visible = True
            CheckBox8.Visible = True
            CheckBox9.Visible = True
            CheckBox10.Visible = True
            CheckBox1.Visible = True
            CheckBox2.Visible = True
            CheckBox3.Visible = True
            CheckBox4.Visible = True
            CheckBox5.Visible = True
            CheckBox6.Visible = True
            CheckBox7.Visible = True
            Button1.Visible = True
            Button2.Visible = True
            PictureBox1.Visible = True
            TextBox3.Visible = True
            TextBox4.Visible = True
            Button3.Visible = False
            Label18.Visible = True
            TextBox9.Visible = True
            TextBox10.Visible = True
            Label19.Visible = True
            TextBox1.ReadOnly = True
            TextBox2.ReadOnly = True
            TextBox5.ReadOnly = True
            TextBox6.ReadOnly = True
            TextBox7.ReadOnly = True
            TextBox8.ReadOnly = True
            TextBox9.ReadOnly = True
            TextBox10.ReadOnly = True
            DateTimePicker1.Enabled = False
        Else
            MsgBox("enfant n'est pas inscri si tu veut le inscrire retourner a l'accueil et séléctionez inscrire")
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim nom As String = TextBox1.Text
        Dim prenom As String = TextBox2.Text
        Dim nom_pere As String = TextBox5.Text
        Dim ncinp As String = TextBox6.Text
        Dim nom_mere As String = TextBox7.Text
        Dim ncinm As String = TextBox8.Text
        Dim prix As String = TextBox9.Text
        Dim selected_date As DateTime = DateTimePicker1.Value
        Dim dat As String = (selected_date.ToString()).Substring(0, 10)
        Dim dat_deb As String = TextBox10.Text
        Dim cat_abonn As String
        Dim shih = True
        'choisir une catégorie d'abonnement
        If (CheckBox1.Checked = False And CheckBox2.Checked = False And CheckBox3.Checked = False And CheckBox4.Checked = False) Then
            MsgBox("séléctionnez les catégories de l'abonnement", MsgBoxStyle.Critical, "erreur")
            shih = False
        ElseIf ((CheckBox1.Checked = True And CheckBox2.Checked = True) Or (CheckBox3.Checked = True And CheckBox4.Checked = True)) Then
            MsgBox("séléctionnez journée complet ou demi_journée et séléctionnez sans repas ou avec repas", MsgBoxStyle.Critical, "erreur")
            shih = False
        ElseIf ((CheckBox1.Checked = True And CheckBox2.Checked = False And CheckBox3.Checked = False And CheckBox4.Checked = False)) Then
            MsgBox("séléctionnez sans repas ou avec repas", MsgBoxStyle.Critical, "erreur")
            shih = False
        ElseIf ((CheckBox1.Checked = False And CheckBox2.Checked = True And CheckBox3.Checked = False And CheckBox4.Checked = False)) Then
            MsgBox("séléctionnez sans repas ou avec repas", MsgBoxStyle.Critical, "erreur")
            shih = False
        ElseIf ((CheckBox1.Checked = False And CheckBox2.Checked = False And CheckBox3.Checked = True And CheckBox4.Checked = False)) Then
            MsgBox("séléctionnez journée compléte ou demi_journée", MsgBoxStyle.Critical, "erreur")
            shih = False
        ElseIf ((CheckBox1.Checked = False And CheckBox2.Checked = False And CheckBox3.Checked = False And CheckBox4.Checked = True)) Then
            MsgBox("séléctionnez journée compléte ou demi_journée", MsgBoxStyle.Critical, "erreur")
            shih = False
        Else
            If (CheckBox1.Checked = True) Then
                cat_abonn = cat_abonn & " journée_complet "
                prix = 300000
            End If
            If (CheckBox2.Checked = True) Then
                cat_abonn = cat_abonn & " demi_journée "
                prix = 150000
            End If
            If (CheckBox3.Checked = True) Then
                cat_abonn = cat_abonn & " avec_repas "
                prix = prix + 15000
            End If
            If (CheckBox4.Checked = True) Then
                cat_abonn = cat_abonn & " sans_repas "
            End If
        End If
        'séléction d'adresse
        Dim adresse As String = TextBox3.Text
        'séléction de sit médicale
        Dim sit_med As String = TextBox4.Text
        If (sit_med <> "bonne" And sit_med <> "BONNE" And sit_med <> "avec maladie" And sit_med <> "AVEC MALADIE") Then
            MsgBox("écrire bonne si vous n'avait aucune maladie et avec maladie si vous avez une maladie", MsgBoxStyle.Information, "NB")
            shih = False
        Else
            If (sit_med = "AVEC MALADIE" Or sit_med = "avec maladie") Then
                prix = prix + 100000
            End If
        End If
        'séléction du(oudes) club(s)
        Dim club As String
        If (CheckBox5.Checked = False And CheckBox6.Checked = False And CheckBox7.Checked = False And CheckBox8.Checked = False And CheckBox9.Checked = False And CheckBox10.Checked = False) Then
            club = "aucune_club"
        Else
            If (CheckBox5.Checked = True) Then
                club = club & "dance "
                prix = prix + 30000
            End If

            If (CheckBox6.Checked = True) Then
                club = club & "quran "
                prix = prix + 40000

            End If
            If (CheckBox7.Checked = True) Then
                club = club & "sport "
                prix = prix + 30000
            End If
            If (CheckBox8.Checked = True) Then
                club = club & "musique "
                prix = prix + 30000
            End If
            If (CheckBox9.Checked = True) Then
                club = club & "calcul_mentale "
                prix = prix + 30000
            End If
            If (CheckBox10.Checked = True) Then
                club = club & "developpement_personnel "
                prix = prix + 30000
            End If
        End If
        If (shih = True) Then
            TextBox9.Text = CStr(prix)
        End If
        effacer(Emplacement)
        If (shih = True) Then
            Dim fs As FileStream
            fs = New FileStream(Emplacement, FileMode.Append, FileAccess.Write)
            Dim sw As StreamWriter
            sw = New StreamWriter(fs)
            sw.WriteLine("info_enfant : ")
            sw.WriteLine(nom)
            sw.WriteLine(prenom)
            sw.WriteLine(dat)
            sw.WriteLine(cat_abonn)
            sw.WriteLine(chemin)
            sw.WriteLine(adresse)
            sw.WriteLine(sit_med)
            sw.WriteLine(club)
            sw.WriteLine("info_parents : ")
            sw.WriteLine(nom_pere)
            sw.WriteLine(ncinp)
            sw.WriteLine(nom_mere)
            sw.WriteLine(ncinm)
            sw.WriteLine(CStr(prix))
            sw.WriteLine(dat_deb)
            sw.WriteLine("------------------------------------------")
            sw.Close()
            fs.Close()
            MsgBox("mise a jour d'enfant avec success", MsgBoxStyle.Information, "bien")
        End If
    End Sub
End Class