﻿Imports System.IO
Imports System.Net.Mime.MediaTypeNames

Public Class Form6
    Function mont_pers(Emplacement As String, ncin_personnel As String) As String
        Dim fs As FileStream
        Dim sr As StreamReader
        fs = New FileStream(Emplacement, FileMode.Open, FileAccess.Read)
        sr = New StreamReader(fs)
        Dim i As Integer = 0
        Dim ligne As String
        Dim test As Boolean = False
        While (sr.Peek() <> -1 And test = False)
            ligne = sr.ReadLine()
            i = i + 1
            If (i = 3 And ncin_personnel = ligne) Then
                ligne = sr.ReadLine()
                TextBox5.Text = ligne
                test = True
            End If
            If (i = 6) Then
                i = 0
            End If
        End While
        If (test = False) Then
            MsgBox("le n°cin du personnel entrée est inexistant")
        End If
        sr.Close()
        fs.Close()
        Return ligne
    End Function
    Function mont(Emplacement As String, ncinp As String, ncinm As String) As String
        Dim fs As FileStream
        Dim sr As StreamReader
        fs = New FileStream(Emplacement, FileMode.Open, FileAccess.Read)
        sr = New StreamReader(fs)
        Dim monta As Integer = 0
        Dim existance As Boolean = False
        Dim i As Integer = 0
        Dim ligne As String
        Dim test As Integer = 0
        While (sr.Peek() <> -1)
            ligne = sr.ReadLine()
            i = i + 1
            If (i = 12 And ncinp = ligne) Then
                test = test + 1
            End If
            If (test = 1 And i = 14 And ncinm = ligne) Then
                test = test + 1
                existance = True
            End If
            If (test = 2 And i = 15) Then
                monta = monta + CInt(ligne)
            End If
            If (i = 17) Then
                i = 0
                test = 0
            End If
        End While
        If (existance = False) Then
            MsgBox("il faut remplir des n°cin des parents existe ")
        End If
        Return monta
    End Function
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Emplacement As String = "C:\Users\ali abdelhak\Desktop\1ére lig\preven\projet\projet\projet\informations_enfant.txt"
        Dim Emplacement1 As String = "C:\Users\ali abdelhak\Desktop\1ére lig\preven\projet\projet\projet\info_perso.txt"
        Dim shih = True
        Dim ncin_pére As String = TextBox2.Text
        If (ncin_pére = "") Then
            MsgBox("le champ n°cin du pére est vide il faut le remplir ", MsgBoxStyle.Critical, "erreur")
            shih = False
        Else
            If (IsNumeric(ncin_pére) = False Or Len(ncin_pére) <> 8) Then
                MsgBox("le n°cin du pére doît être numerique de 8 chiffres", MsgBoxStyle.Critical, "erreur")
                shih = False
            End If
        End If
        Dim ncin_mére As String = TextBox1.Text
        If (ncin_mére = "") Then
            MsgBox("le champ n°cin du mére est vide il faut le remplir ", MsgBoxStyle.Critical, "erreur")
            shih = False
        Else
            If (IsNumeric(ncin_mére) = False Or Len(ncin_mére) <> 8) Then
                MsgBox("le n°cin du mére doît être numerique de 8 chiffres", MsgBoxStyle.Critical, "erreur")
                shih = False
            End If
        End If
        Dim ncin_personnel As String = TextBox4.Text
        If (ncin_personnel = "") Then
            MsgBox("le champ ncin du personnel est vide il faut le remplir ", MsgBoxStyle.Critical, "erreur")
            shih = False
        Else
            If (IsNumeric(ncin_personnel) = False Or Len(ncin_personnel) <> 8) Then
                MsgBox("le n°cin du personnel doît être numerique de 8 chiffres", MsgBoxStyle.Critical, "erreur")
                shih = False
            End If
        End If
        Dim montant_par As String = mont(Emplacement, ncin_pére, ncin_mére)
        TextBox3.Text = montant_par
        Dim montant_pers As String = mont_pers(Emplacement1, ncin_personnel)
    End Sub
End Class