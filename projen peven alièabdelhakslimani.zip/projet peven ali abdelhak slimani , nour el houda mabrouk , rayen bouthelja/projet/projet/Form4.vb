﻿Imports System.IO
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Form4
    Function test(ByVal var As String) As Integer
        Dim i As Int16
        i = 0
        Dim testi As Int16
        testi = 0
        If (var(0) <= "Z" And var(0) >= "A") Then
            i = i + 1
            While (testi = 0 And i <= Len(var) - 1)
                If (Char.ToUpper(var(i)) <= "Z" And Char.ToUpper(var(i)) >= "A") Then
                    i = i + 1
                Else
                    testi = 1
                End If
            End While
        Else
            testi = 1
        End If
        Return testi
    End Function
    Function exist(ByVal Emplacement As String, ncin As String) As Boolean
        Dim fs As FileStream
        Dim sr As StreamReader
        fs = New FileStream(Emplacement, FileMode.Open, FileAccess.Read)
        sr = New StreamReader(fs)
        'nombre des lignes de fichier
        Dim ligne As String
        Dim Test As Boolean = False
        Dim i = 0
        While (sr.Peek <> -1 And Test = False)
            ligne = sr.ReadLine()
            i = i + 1
            If (i = 3) Then
                If (ligne = ncin) Then
                    Test = True
                End If
            End If
            If (i = 6) Then
                i = 0
            End If
        End While
        sr.Close()
        fs.Close()
        Return Test
    End Function

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        'nom et prénom
        Dim shih As Boolean = True
        Dim Nom As String = TextBox1.Text

        Dim prenom As String = TextBox2.Text
        If (Nom <> "" And prenom <> "") Then
            If (test(Nom) = 1) Then
                MsgBox("donnez une nom valide qui commence par une lettre majuscule et composé uniquement par des lettres", MsgBoxStyle.Critical, "erreur")
                shih = False
            End If
            If (test(prenom) = 1) Then
                MsgBox("donnez une prenom valide qui commence par une lettre majuscule et composé uniquement par des lettres", MsgBoxStyle.Critical, "erreur")
                shih = False
            End If

        ElseIf (prenom = "" Or Nom = "") Then
            MsgBox("le champ du nom et du prenom doivent être rempli", MsgBoxStyle.Critical, "erreur")
            shih = False
        End If
        Dim ncin_personnel As String = TextBox3.Text
        If (ncin_personnel = "") Then
            MsgBox("le champ ncin du personnel est vide il faut le remplir ", MsgBoxStyle.Critical, "erreur")
            shih = False
        Else
            If (IsNumeric(ncin_personnel) = False Or Len(ncin_personnel) <> 8) Then
                MsgBox("le n°cin du personnel doît être numerique de 8 chiffres", MsgBoxStyle.Critical, "erreur")
                shih = False
            End If
        End If
        Dim salaire_perso As String = TextBox4.Text
        If (salaire_perso = "") Then
            MsgBox("le champ salaire du personnel est vide il faut le remplir", MsgBoxStyle.Critical, "erreur")
            shih = False
        Else
            If (IsNumeric(salaire_perso) = False) Then
                MsgBox("le salaire du personnel doît être numerique", MsgBoxStyle.Critical, "erreur")
                shih = False
            End If
        End If
        If (shih = True) Then
            Dim datdeb As String = Now().Day
            If (exist("C:\Users\ali abdelhak\Desktop\1ére lig\preven\projet\projet\projet\info_perso.txt", ncin_personnel) = False) Then
                Dim fs As FileStream
                fs = New FileStream("C:\Users\ali abdelhak\Desktop\1ére lig\preven\projet\projet\projet\info_perso.txt", FileMode.Append, FileAccess.Write)
                Dim sw As StreamWriter
                sw = New StreamWriter(fs)
                sw.WriteLine(Nom)
                sw.WriteLine(prenom)
                sw.WriteLine(ncin_personnel)
                sw.WriteLine(salaire_perso)
                sw.WriteLine(datdeb)
                sw.WriteLine("------------------")
                sw.Close()
                fs.Close()
                MsgBox("ajout avec succées", MsgBoxStyle.Information, "bravo")
            Else
                MsgBox("ce personnel est existant", MsgBoxStyle.Critical, "erreur")
            End If
        End If
    End Sub


End Class