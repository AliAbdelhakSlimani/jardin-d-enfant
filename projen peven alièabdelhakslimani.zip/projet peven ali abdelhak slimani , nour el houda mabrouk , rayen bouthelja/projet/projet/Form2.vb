﻿Imports System.Security
Imports System.IO
Public Class Form2
    Dim butt_click As Boolean = False
    Dim chemin As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'choisir une image 
        choisirimage.ShowDialog()
        If (choisirimage.ShowDialog = 1) Then
            butt_click = True
            Dim File1 As String = choisirimage.FileName
            Dim test As String = File1.Substring(File1.IndexOf(".") + 1, Len(File1) - Len(File1.Substring(0, File1.IndexOf(".") + 1)))
            If (test <> "jpg" And test <> "JPG" And test <> "JPEG" And test <> "jpeg" And test <> "BMP" And test <> "bmp" And test <> "PNG" And test <> "png") Then
                MsgBox("erreur , svp entrez une image de format JPEG , JPG , BMP ou PNG", MsgBoxStyle.Critical, "erreur")
            Else
                Dim File As String = choisirimage.FileName
                chemin = File
                PictureBox1.Image = Image.FromFile(File)
            End If
        End If
    End Sub
    Function test(ByVal var As String) As Integer
        Dim i As Int16
        i = 0
        Dim testi As Int16
        testi = 0
        If (var(0) <= "Z" And var(0) >= "A") Then
            i = i + 1
            While (testi = 0 And i <= Len(var) - 1)
                If (Char.ToUpper(var(i)) <= "Z" And Char.ToUpper(var(i)) >= "A") Then
                    i = i + 1
                Else
                    testi = 1
                End If
            End While
        Else
            testi = 1
        End If
        Return testi
    End Function
    Sub ecrire(ByVal var As String, ByVal Emplacement As String)
        Using Writer As New System.IO.StreamWriter(Emplacement, True)
            Writer.WriteLine(var)
        End Using

    End Sub
    Function exist(ByVal Emplacement As String, ByVal Nom As String, ByVal prenom As String, ByVal dat As String, ByVal npére As String, ByVal ncinp As String, ByVal nmére As String, ByVal ncinm As String) As Boolean
        Dim testi As Integer = 0
        Dim i As Integer = 0
        Using lirefich As New StreamReader(Emplacement)
            Dim ligne As String
            Do
                ligne = lirefich.ReadLine()
                i = i + 1
                'les testes pour assusrer que l'enfant est nouveau et s'il s'agit d'un existant en retourne une valeur
                If (ligne IsNot Nothing) Then
                    If (ligne = Nom And i = 2) Then
                        testi = testi + 1
                    End If
                    If (ligne = prenom And i = 3) Then
                        testi = testi + 1
                    End If
                    If (ligne = dat And i = 4) Then
                        testi = testi + 1
                    End If
                    If (ligne = npére And i = 11) Then
                        testi = testi + 1
                    End If
                    If (ligne = ncinp And i = 12) Then
                        testi = testi + 1
                    End If
                    If (ligne = nmére And i = 13) Then
                        testi = testi + 1
                    End If
                    If (ligne = ncinm And i = 14) Then
                        testi = testi + 1
                    End If
                    If (i = 17) Then
                        i = 0
                        testi = 0
                    End If
                End If
            Loop Until ligne Is Nothing Or testi = 7
        End Using
        Return testi = 7
    End Function
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim Emplacement As String = "C:\Users\ali abdelhak\Desktop\1ére lig\preven\projet\projet\projet\informations_enfant.txt"
        Dim ligne As String
        Dim shih As Boolean = True
        Dim cat_abonn As String = ""
        Dim prix As Integer = 0
        'nom et prénom
        Dim Nom As String = TextBox1.Text
        Dim prenom As String = TextBox2.Text
        If (Nom <> "" And prenom <> "") Then
            If (test(Nom) = 1) Then
                MsgBox("donnez une nom valide qui commence par une lettre majuscule et composé uniquement par des lettres", MsgBoxStyle.Critical, "erreur")
                shih = False
            End If
            If (test(prenom) = 1) Then
                MsgBox("donnez une prenom valide qui commence par une lettre majuscule et composé uniquement par des lettres", MsgBoxStyle.Critical, "erreur")
                shih = False
            End If

        ElseIf (prenom = "" Or Nom = "") Then
            MsgBox("le champ du nom et du prenom doivent être rempli", MsgBoxStyle.Critical, "erreur")
            shih = False
        End If
        'selection du date de naissance
        Dim selected_date As DateTime = DateTimePicker1.Value
        Dim Dat_deb As Date = Now()
        Dim Dat_deb_str As String = Dat_deb.ToString().Substring(0, 10)
        Dim dat As String = selected_date.ToString()
        Dim Annee As String = dat.Substring(6, 4)
        Dim Annee_ent As Integer = CInt(Annee)
        If (Year(Now) - Annee_ent <= 2) Then
            MsgBox("votre 'enfant' c'est un bébé n'est pas un enfant", MsgBoxStyle.Critical, "erreur")
            shih = False
        End If
        If (Year(Now) - Annee_ent >= 6) Then
            MsgBox("votre enfant n'est plus un enfant il est agé " & CStr(Year(Now) - Annee_ent), MsgBoxStyle.Critical, "erreur")
            shih = False
        End If
        'choisir une catégorie d'abonnement
        If (CheckBox1.Checked = False And CheckBox2.Checked = False And CheckBox3.Checked = False And CheckBox4.Checked = False) Then
            MsgBox("séléctionnez les catégories de l'abonnement", MsgBoxStyle.Critical, "erreur")
            shih = False
        ElseIf ((CheckBox1.Checked = True And CheckBox2.Checked = True) Or (CheckBox3.Checked = True And CheckBox4.Checked = True)) Then
            MsgBox("séléctionnez journée complet ou demi_journée et séléctionnez sans repas ou avec repas", MsgBoxStyle.Critical, "erreur")
            shih = False
        ElseIf ((CheckBox1.Checked = True And CheckBox2.Checked = False And CheckBox3.Checked = False And CheckBox4.Checked = False)) Then
            MsgBox("séléctionnez sans repas ou avec repas", MsgBoxStyle.Critical, "erreur")
            shih = False
        ElseIf ((CheckBox1.Checked = False And CheckBox2.Checked = True And CheckBox3.Checked = False And CheckBox4.Checked = False)) Then
            MsgBox("séléctionnez sans repas ou avec repas", MsgBoxStyle.Critical, "erreur")
            shih = False
        ElseIf ((CheckBox1.Checked = False And CheckBox2.Checked = False And CheckBox3.Checked = True And CheckBox4.Checked = False)) Then
            MsgBox("séléctionnez journée compléte ou demi_journée", MsgBoxStyle.Critical, "erreur")
            shih = False
        ElseIf ((CheckBox1.Checked = False And CheckBox2.Checked = False And CheckBox3.Checked = False And CheckBox4.Checked = True)) Then
            MsgBox("séléctionnez journée compléte ou demi_journée", MsgBoxStyle.Critical, "erreur")
            shih = False
        Else
            If (CheckBox1.Checked = True) Then
                cat_abonn = cat_abonn & " journée_complet "
                prix = 300000
            End If
            If (CheckBox2.Checked = True) Then
                cat_abonn = cat_abonn & " demi_journée "
                prix = 150000
            End If
            If (CheckBox3.Checked = True) Then
                cat_abonn = cat_abonn & " avec_repas "
                prix = prix + 15000
            End If
            If (CheckBox4.Checked = True) Then
                cat_abonn = cat_abonn & " sans_repas "
            End If
        End If
        'séléction d'image
        If (butt_click = False) Then
            MsgBox("il faut choisir une image", MsgBoxStyle.Critical, "erreur")
            shih = False
        End If
        'séléction d'adresse
        Dim adresse As String = TextBox3.Text
        'séléction de sit médicale
        Dim sit_med As String = TextBox4.Text
        If (sit_med <> "bonne" And sit_med <> "BONNE" And sit_med <> "avec maladie" And sit_med <> "AVEC MALADIE") Then
            MsgBox("écrire bonne si vous n'avait aucune maladie et avec maladie si vous avez une maladie", MsgBoxStyle.Information, "NB")
            shih = False
        Else
            If (sit_med = "AVEC MALADIE" Or sit_med = "avec maladie") Then
                prix = prix + 100000
            End If
        End If
        'séléction du(oudes) club(s)
        Dim club As String
        If (CheckBox5.Checked = False And CheckBox6.Checked = False And CheckBox7.Checked = False And CheckBox8.Checked = False And CheckBox9.Checked = False And CheckBox10.Checked = False) Then
            club = "aucune_club "
        Else
            If (CheckBox5.Checked = True) Then
                club = club & "dance "
                prix = prix + 30000
            End If

            If (CheckBox6.Checked = True) Then
                club = club & "quran "
                prix = prix + 40000

            End If
            If (CheckBox7.Checked = True) Then
                club = club & "sport "
                prix = prix + 30000
            End If
            If (CheckBox8.Checked = True) Then
                club = club & "musique "
                prix = prix + 30000
            End If
            If (CheckBox9.Checked = True) Then
                club = club & "calcul_mentale "
                prix = prix + 30000
            End If
            If (CheckBox10.Checked = True) Then
                club = club & "developpement_personnel "
                prix = prix + 30000
            End If
        End If
        'séléction du nom et prénom du pére
        Dim Nometpren_pére As String = TextBox5.Text
        If (Nometpren_pére = "") Then
            MsgBox("le champ du nom et prénom du pére doit être rempli", MsgBoxStyle.Critical, "erreur")
            shih = False
        End If
        'Séléction du Ncin du pére
        Dim Ncin_pére As String = TextBox6.Text
        If (Ncin_pére = "") Then
            MsgBox("le champ ncin du mére doit être rempli ")
            shih = False
        Else
            If (IsNumeric(Ncin_pére) = False Or Len(Ncin_pére) <> 8) Then
                MsgBox("le n°cin du pére doît être numerice de 8 chiffres", MsgBoxStyle.Critical, "erreur")
                shih = False
            End If
        End If
        'séléction du nom et prénom du mére 
        Dim Nometpren_mére As String = TextBox7.Text
        If (Nometpren_mére = "") Then
            MsgBox("le champ du nom et prénom du mére doit être rempli", MsgBoxStyle.Critical, "erreur")
            shih = False
        End If
        'Séléction du Ncin du mére
        Dim Ncin_mére As String = TextBox8.Text
        If (Ncin_mére = "") Then
            MsgBox("le champ ncin du mére doit être rempli ")
            shih = False
        Else
            If (IsNumeric(Ncin_mére) = False Or Len(Ncin_mére) <> 8) Then
                MsgBox("le n°cin du mére doît être numerice de 8 chiffres", MsgBoxStyle.Critical, "erreur")
                shih = False
            End If
        End If
        If (shih = True) Then
            If (Ncin_mére = Ncin_pére) Then
                shih = False
                MsgBox("vous avez entrée deux numéro de cin identiques entrez des numéro de cin valide svp", MsgBoxStyle.Critical, "erreur")
            End If
        End If
        If (shih = True) Then
            If (exist(Emplacement, Nom, prenom, dat.Substring(0, 10), Nometpren_pére, Ncin_pére, Nometpren_mére, Ncin_mére) = False) Then
                ecrire("info_enfant : ", Emplacement)
                ecrire(Nom, Emplacement)
                ecrire(prenom, Emplacement)
                ecrire(dat.Substring(0, 10), Emplacement)
                ecrire(cat_abonn, Emplacement)
                ecrire(chemin, Emplacement)
                ecrire(adresse, Emplacement)
                ecrire(sit_med, Emplacement)
                ecrire(club, Emplacement)
                ecrire("info_parents : ", Emplacement)
                ecrire(Nometpren_pére, Emplacement)
                ecrire(Ncin_pére, Emplacement)
                ecrire(Nometpren_mére, Emplacement)
                ecrire(Ncin_mére, Emplacement)
                ecrire(CStr(prix), Emplacement)
                ecrire(Dat_deb_str, Emplacement)
                ecrire("------------------------------------------", Emplacement)
                MsgBox("inscription avec succees", MsgBoxStyle.Information, "inscri")
            Else
                MsgBox("l'enfant que vous avez entrée c'est un enfant existant", MsgBoxStyle.Critical, "erreur")
                MsgBox("si tu veux changer des informations ou visualiser les informations retourner a l'acceueil et clicker sur le boutton correspondant", MsgBoxStyle.Information, "NB")
            End If
        End If

    End Sub


End Class