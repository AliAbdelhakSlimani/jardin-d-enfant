﻿Imports System.IO
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.Button

Public Class Form10
    Private WithEvents printDoc As New Printing.PrintDocument
    Private printDialog As New PrintDialog
    Function exist(ByVal Emplacement As String, ByVal Nom As String, ByVal prenom As String, ByVal dat As String, ByVal npére As String, ByVal ncinp As String, ByVal nmére As String, ByVal ncinm As String) As Boolean

        Dim testi As Integer = 0
        Dim fs As FileStream
        Dim sr As StreamReader
        fs = New FileStream(Emplacement, FileMode.Open, FileAccess.Read)
        sr = New StreamReader(fs)
        'nombre des lignes de fichier
        Dim i = 0
        Dim ligne As String
        Dim k As Integer
        While (sr.Peek <> -1 And i <> 17)

            ligne = sr.ReadLine()
            i += 1

            If (ligne = Nom And i = 2) Then
                testi = testi + 1
            End If
            If (ligne = prenom And i = 3) Then
                testi = testi + 1
            End If
            If (ligne = dat And i = 4) Then
                testi = testi + 1
            End If
            If (ligne = npére And i = 11) Then
                testi = testi + 1
            End If
            If (ligne = ncinp And i = 12) Then
                testi = testi + 1
            End If
            If (ligne = nmére And i = 13) Then
                testi = testi + 1
            End If
            If (ligne = ncinm And i = 14) Then
                testi = testi + 1
            End If
            If (i = 17) Then
                i = 0
                testi = 0
            End If
            If (testi = 7 And i = 16) Then
                i = 17
            End If
        End While
        sr.Close()
        fs.Close()
        Return testi = 7
    End Function
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim Emplacement As String = "C:\Users\ali abdelhak\Desktop\1ére lig\preven\projet\projet\projet\informations_enfant.txt"
        Dim Nom As String = TextBox1.Text
        Dim prenom As String = TextBox2.Text
        Dim selected_date As DateTime = DateTimePicker1.Value
        Dim dat As String = selected_date.ToString().Substring(0, 10)
        Dim Nometpren_pére As String = TextBox5.Text
        Dim Ncin_pére As String = TextBox6.Text
        Dim Nometpren_mére As String = TextBox7.Text
        Dim Ncin_mére As String = TextBox8.Text
        If (exist(Emplacement, Nom, prenom, dat, Nometpren_pére, Ncin_pére, Nometpren_mére, Ncin_mére) = True) Then
            'Form9.Show()
            Me.BackgroundImage = Image.FromFile("C:\Users\ali abdelhak\Desktop\1ére lig\preven\projet\projet\projet\diplome.jpg")
            Me.BackgroundImageLayout = ImageLayout.Stretch
            Label1.Visible = False
            Label14.Visible = False
            Label15.Visible = False
            Label3.Visible = False
            Label4.Visible = False
            Label5.Visible = False
            Label12.Visible = False
            Label13.Visible = False
            Label16.Visible = False
            Label17.Visible = False
            TextBox1.Visible = False
            TextBox2.Visible = False
            DateTimePicker1.Visible = False
            TextBox5.Visible = False
            TextBox6.Visible = False
            TextBox7.Visible = False
            TextBox8.Visible = False
            Button3.Visible = False
            Label2.Visible = True
            Label2.Text = Nom & "  " & prenom
            Label6.Visible = True
            Label6.Text = "Tu as en toi une force incroyable, une capacité à apprendre et à grandir." & vbCrLf & "N'oublie jamais  que chaque défi que tu rencontres te rend plus fort." & vbCrLf & " Alors, n'aie pas peur d'explorer, de créer, et de rêver. Tu es capable de" & vbCrLf & "réaliser de grandes choses, et je suis là pour t'encourager à chaque étape" & vbCrLf & "de ton chemin vers le succès. Crois en toi et en toutes les possibilités" & vbCrLf & " qui t'attendent !"
            Label7.Visible = True
            Label7.Text = (Now().ToString).Substring(0, 10)
            Label8.Visible = True
            If printDialog.ShowDialog = DialogResult.OK Then
                printDoc.Print()
            End If
        Else
            MsgBox("enfant inexistant ", MsgBoxStyle.Critical, "erreur")
        End If
    End Sub
    Private Sub printDoc_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles printDoc.PrintPage
        Dim bmp As New Bitmap(Me.Width, Me.Height)
        Me.DrawToBitmap(bmp, New Rectangle(0, 0, Me.Width, Me.Height))
        e.Graphics.DrawImage(bmp, 0, 0)
    End Sub


End Class