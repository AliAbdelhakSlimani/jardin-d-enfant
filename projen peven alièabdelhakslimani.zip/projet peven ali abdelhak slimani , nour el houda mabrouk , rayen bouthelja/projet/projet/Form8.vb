﻿Imports System.IO

Public Class Form8
    Function dep(Emplacement1 As String) As String
        Dim fs As FileStream
        Dim sr As StreamReader
        fs = New FileStream(Emplacement1, FileMode.Open, FileAccess.Read)
        sr = New StreamReader(fs)
        Dim depe As Integer = 0
        Dim i As Integer = 0
        Dim ligne As String
        While (sr.Peek() <> -1)
            ligne = sr.ReadLine()
            i = i + 1
            If (i = 4) Then
                depe = depe + CInt(ligne)
            End If
            If (i = 6) Then
                i = 0
            End If
        End While
        Return depe
    End Function
    Function mont(Emplacement As String) As String

        Dim fs As FileStream
        Dim sr As StreamReader
        fs = New FileStream(Emplacement, FileMode.Open, FileAccess.Read)
        sr = New StreamReader(fs)
        Dim monta As Integer = 0
        Dim i As Integer = 0
        Dim ligne As String
        While (sr.Peek() <> -1)
            ligne = sr.ReadLine()
            i = i + 1
            If (i = 15) Then
                monta = monta + CInt(ligne)
            End If
            If (i = 17) Then
                i = 0
            End If
        End While
        Return monta
    End Function
    Private Sub Form8_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim Emplacement As String = "C:\Users\ali abdelhak\Desktop\1ére lig\preven\projet\projet\projet\informations_enfant.txt"
        Dim Emplacement1 As String = "C:\Users\ali abdelhak\Desktop\1ére lig\preven\projet\projet\projet\info_perso.txt"
        Dim recette As String = mont(Emplacement)
        TextBox2.Text = recette
        Dim depenses As String = dep(Emplacement1)
        TextBox1.Text = depenses
        TextBox5.Text = CStr(CInt(TextBox2.Text) - CInt(TextBox1.Text))
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim recette_vo As String = TextBox4.Text

        If (IsNumeric(recette_vo) = False) Then
            MsgBox("donnez des recette_voyages en des nombre", MsgBoxStyle.Critical, "erreur")
        End If
        TextBox2.Text = CStr(CInt(TextBox2.Text) + CInt(recette_vo))
        TextBox5.Text = CStr(CInt(TextBox2.Text) - CInt(TextBox1.Text))
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim frais_supp As String = TextBox3.Text
        If (IsNumeric(frais_supp) = False) Then
            MsgBox("donnez des frais supplémentaires en des nombre", MsgBoxStyle.Critical, "erreur")
        End If
        TextBox1.Text = CStr(CInt(TextBox1.Text) + CInt(frais_supp))
        TextBox5.Text = CStr(CInt(TextBox2.Text) - CInt(TextBox1.Text))
    End Sub
End Class