﻿Imports System.IO

Public Class Form5
    Dim blasa As Integer
    Function test(ByVal var As String) As Integer
        Dim i As Int16
        i = 0
        Dim testi As Int16
        testi = 0
        If (var(0) <= "Z" And var(0) >= "A") Then
            i = i + 1
            While (testi = 0 And i <= Len(var) - 1)
                If (Char.ToUpper(var(i)) <= "Z" And Char.ToUpper(var(i)) >= "A") Then
                    i = i + 1
                Else
                    testi = 1
                End If
            End While
        Else
            testi = 1
        End If
        Return testi
    End Function

    Function exist(ByVal Emplacement As String, ncin As String) As Boolean
        Dim fs As FileStream
        Dim sr As StreamReader
        fs = New FileStream(Emplacement, FileMode.Open, FileAccess.Read)
        sr = New StreamReader(fs)
        Dim ligne As String
        Dim info(6) As String
        Dim Test As Boolean = False
        Dim i = 0
        Dim nb_ligne As Integer = 0
        While (sr.Peek <> -1 And Test = False)
            ligne = sr.ReadLine()
            info(i) = ligne
            i = i + 1
            If (i = 3) Then
                If (ligne = ncin) Then
                    blasa = nb_ligne + 1
                    Test = True
                    ligne = sr.ReadLine()
                    info(i) = ligne
                End If
            End If
            If (i = 6) Then
                nb_ligne = nb_ligne + 1
                i = 0
            End If
        End While
        sr.Close()
        fs.Close()
        If (Test = True) Then
            TextBox1.Text = info(0)
            TextBox2.Text = info(1)
            TextBox4.Text = info(3)
            TextBox3.Enabled = False
        End If
        Return Test
    End Function
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim shih As Boolean = True
        Dim ncin_personnel As String = TextBox3.Text
        If (ncin_personnel = "") Then
            MsgBox("le champ ncin du personnel est vide il faut le remplir ", MsgBoxStyle.Critical, "erreur")
            shih = False
        Else
            If (IsNumeric(ncin_personnel) = False Or Len(ncin_personnel) <> 8) Then
                MsgBox("le n°cin du personnel doît être numerique de 8 chiffres", MsgBoxStyle.Critical, "erreur")
                shih = False
            End If
        End If
        If (shih = True) Then
            If (exist("C:\Users\ali abdelhak\Desktop\1ére lig\preven\projet\projet\projet\info_perso.txt", ncin_personnel) = True) Then
                Button1.Visible = True
                Button3.Visible = False
                Label4.Visible = True
                Label2.Visible = True
                Label5.Visible = True
                TextBox1.Visible = True
                TextBox2.Visible = True
                TextBox4.Visible = True
            Else
                MsgBox("ce personnel n'existe pas ", MsgBoxStyle.Information, "info")
            End If
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Emplacement As String = "C:\Users\ali abdelhak\Desktop\1ére lig\preven\projet\projet\projet\info_perso.txt"
        Dim ncin As String = TextBox3.Text
        Dim shih As Boolean = True
        Dim salaire As String = TextBox4.Text
        If (salaire = "") Then
            MsgBox("le champ salaire du personnel est vide il faut le remplir ", MsgBoxStyle.Critical, "erreur")
            shih = False
        Else
            If (IsNumeric(salaire) = False) Then
                MsgBox("le salaire du personnel doît être numerique", MsgBoxStyle.Critical, "erreur")
                shih = False
            End If
        End If
        If (shih = True) Then
            Dim fs As FileStream
            Dim sr As StreamReader
            fs = New FileStream(Emplacement, FileMode.Open, FileAccess.Read)
            sr = New StreamReader(fs)
            Dim ligne As String
            Dim Test As Boolean = False
            Dim i = 0
            Dim nb_ligne As Integer = 0
            Dim txt As String
            While (sr.Peek <> -1)
                ligne = sr.ReadLine()
                i = i + 1
                If (blasa = nb_ligne + 1) Then
                    If (i = 4) Then
                        txt = txt & salaire & vbCrLf
                    Else
                        txt = txt & ligne & vbCrLf
                    End If
                Else
                    txt = txt & ligne & vbCrLf
                End If
                If (i = 6) Then
                    i = 0
                    nb_ligne = nb_ligne + 1
                End If
            End While
            sr.Close()
            fs.Close()
            fs = New FileStream(Emplacement, FileMode.Create, FileAccess.Write)
            Dim sw As StreamWriter
            sw = New StreamWriter(fs)
            sw.Write(txt)
            MsgBox("mise à jour avec succées", MsgBoxStyle.Information, "info")
            sw.Close()
            fs.Close()
        End If
    End Sub
End Class